Q3 :
DecisionTree.py : Normal Decision Tree implementation without optimizations
DecisionTree-Pruned.py : Decision Tree implementation with pruning optimization using mean for splitting
DecisionTree-Pruned-2.py : Decision Tree implementation with pruning optimization using best split method
DecisionTree-GiniIndex.py : Decision Tree implementation with gini index and pruning

Q4 :
DecisionTree.py : Implementation using sklearn DecisionTree
MultinomialNaiveBayes.py : Implementation using Multinomial Naive Bayes
BernoulliNaiveBayes.py :Implementation using Bernoulli Naive Bayess
